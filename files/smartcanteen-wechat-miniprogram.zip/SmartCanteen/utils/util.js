// utils/util.js — shared helpers
const { dishes } = require('../data/dishes');
const { canteens } = require('../data/canteens');
const { getCrowdSnapshot } = require('../data/crowd');

function getCanteen(id) {
  return canteens.find((c) => c.id === id) || null;
}

function getDish(id) {
  return dishes.find((d) => d.id === id) || null;
}

function fmtPrice(p) {
  return '¥' + p;
}

// Dietary tag list for a dish (e.g. "Vegetarian", "Halal", "Spicy")
function dietTags(dish, lang) {
  const tags = [];
  const zh = lang === 'zh';
  if (dish.dietary.vegetarian) tags.push(zh ? '素食' : 'Vegetarian');
  if (dish.dietary.vegan) tags.push(zh ? '纯素' : 'Vegan');
  if (dish.dietary.halal) tags.push(zh ? '清真' : 'Halal');
  if (dish.dietary.pork) tags.push(zh ? '含猪肉' : 'Pork');
  if (dish.dietary.beef) tags.push(zh ? '含牛肉' : 'Beef');
  if (dish.spicy) tags.push(zh ? '辣' : 'Spicy');
  return tags;
}

// Apply user preferences + search + price cap to the dish list.
function filterDishes(opts) {
  const {
    query = '',
    dietaryPrefs = [],
    allergens = [],
    maxPrice = null,
    canteenId = null,
  } = opts || {};

  return dishes.filter((d) => {
    // canteen
    if (canteenId && d.canteenId !== canteenId) return false;
    // price cap
    if (maxPrice != null && d.price > maxPrice) return false;

    // dietary prefs — "no pork" / "no beef" / "vegetarian" / "vegan" / "halal"
    for (const p of dietaryPrefs) {
      if (p === 'noPork' && d.dietary.pork) return false;
      if (p === 'noBeef' && d.dietary.beef) return false;
      if (p === 'vegetarian' && !d.dietary.vegetarian) return false;
      if (p === 'vegan' && !d.dietary.vegan) return false;
      if (p === 'halal' && !d.dietary.halal) return false;
    }

    // allergens — exclude if the dish contains a listed allergen OR info unavailable
    for (const a of allergens) {
      if (d.allergens.includes(a)) return false;
      if (d.allergenInfo === 'unavailable') return false;
    }

    // text search (matches EN, ZH, and ingredients)
    if (query) {
      const q = query.toLowerCase();
      const hay = [
        d.name.en.toLowerCase(),
        d.name.zh,
        ...d.ingredients.map((s) => s.toLowerCase()),
      ].join(' ');
      if (!hay.includes(q)) return false;
    }

    return true;
  });
}

// Favorites (stored as array of dish ids)
function getFavorites() {
  return wx.getStorageSync('smartcanteen_favs') || [];
}
function isFavorite(id) {
  return getFavorites().includes(id);
}
function toggleFavorite(id) {
  let favs = getFavorites();
  const i = favs.indexOf(id);
  if (i >= 0) favs.splice(i, 1);
  else favs.push(id);
  wx.setStorageSync('smartcanteen_favs', favs);
  return favs.includes(id);
}

// ---- nutrition / meal log ----
// Each entry: { dishId, time } keyed by day string 'YYYY-MM-DD'.
function dayKey(ts) {
  const d = new Date(ts);
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

function getMealLog() {
  return wx.getStorageSync('smartcanteen_meals') || {};
}

function logMeal(dishId) {
  const log = getMealLog();
  const key = dayKey(Date.now());
  log[key] = log[key] || [];
  log[key].push({ dishId, time: Date.now() });
  wx.setStorageSync('smartcanteen_meals', log);
}

// Aggregate nutrition for a given day's logged meals.
// Returns { kcal, protein, fat, carbs, count } or null if no meals.
function dayNutrition(dayStr) {
  const log = getMealLog();
  const entries = log[dayStr] || [];
  if (!entries.length) return null;
  const agg = { kcal: 0, protein: 0, fat: 0, carbs: 0, count: entries.length };
  entries.forEach((e) => {
    const d = getDish(e.dishId);
    if (!d) return;
    agg.kcal += d.nutrition.kcal;
    agg.protein += d.nutrition.protein;
    agg.fat += d.nutrition.fat;
    agg.carbs += d.nutrition.carbs;
  });
  return agg;
}

// Last N days (including today), oldest first.
function lastNDays(n) {
  const out = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000);
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    out.push({ key: `${d.getFullYear()}-${m}-${day}`, label: `${m}/${day}` });
  }
  return out;
}

module.exports = {
  getCanteen,
  getDish,
  fmtPrice,
  dietTags,
  filterDishes,
  getFavorites,
  isFavorite,
  toggleFavorite,
  logMeal,
  getMealLog,
  dayNutrition,
  lastNDays,
  crowd: getCrowdSnapshot,
};
