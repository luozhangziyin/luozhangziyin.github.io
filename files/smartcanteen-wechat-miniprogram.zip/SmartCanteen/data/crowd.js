// crowd.js — simulated real-time crowd & seating data (beta)
// In production this is fed by the computer-vision / QR occupancy pipeline.
// For the prototype, we deterministically generate a plausible "now" reading
// so the app is fully demonstrable without a live camera.

const { canteens } = require('./canteens');

// Zone occupancy ratios (0..1) keyed by canteenId.
// Simulated — replace with live API data later.
const zoneOccupancy = {
  zijin: { A: 0.82, B: 0.51, C: 0.23 },
  taoli: { A: 0.66, B: 0.40 },
  zhichun: { A: 0.34, B: 0.20 },
  qingfen: { A: 0.58, B: 0.31 },
  guanyuan: { A: 0.72 },
};

// Simple wave model to vary "now" depending on time of day.
function timeFactor() {
  const now = new Date();
  const h = now.getHours() + now.getMinutes() / 60;
  // lunch peak ~12, dinner peak ~18
  const lunch = Math.exp(-Math.pow((h - 12) / 1.6, 2));
  const dinner = Math.exp(-Math.pow((h - 18) / 1.6, 2));
  const base = 0.35;
  return Math.min(1, base + 0.6 * Math.max(lunch, dinner));
}

// Build a live snapshot for every canteen.
function getCrowdSnapshot() {
  const f = timeFactor();
  return canteens.map((c) => {
    const zones = c.zones.map((z) => {
      const base = zoneOccupancy[c.id] ? (zoneOccupancy[c.id][z] ?? 0.3) : 0.3;
      const ratio = Math.min(1, base * f);
      return { name: z, occupancy: Math.round(ratio * 100) };
    });
    const seatsPerZone = Math.round(c.totalSeats / c.zones.length);
    const occupied = Math.round(
      zones.reduce((s, z) => s + z.occupancy / 100 * seatsPerZone, 0)
    );
    const free = c.totalSeats - occupied;
    const occupancy = Math.round((occupied / c.totalSeats) * 100);
    return {
      id: c.id,
      name: c.name,
      floors: c.floors,
      people: Math.round(occupied * 0.9), // approx people vs seats
      occupied,
      free,
      totalSeats: c.totalSeats,
      occupancy,
      zones,
      level: levelOf(occupancy),
    };
  });
}

function levelOf(occ) {
  if (occ < 40) return 'low';
  if (occ < 60) return 'medium';
  if (occ < 80) return 'high';
  return 'very_high';
}

module.exports = { getCrowdSnapshot, levelOf, timeFactor };
