// canteens.js — canteen catalogue
// Each canteen: id, name (en/zh), floor, zones, totalSeats, coords (approx on campus)
const canteens = [
  {
    id: 'zijin',
    name: { en: 'Zijing Canteen', zh: '紫荆食堂' },
    floors: ['1F', '2F', '3F'],
    zones: ['A', 'B', 'C'],
    totalSeats: 1200,
    pos: { en: 'Zijing Apartment area', zh: '紫荆公寓区' },
  },
  {
    id: 'taoli',
    name: { en: 'Taoli Canteen', zh: '桃李食堂' },
    floors: ['1F', '2F'],
    zones: ['A', 'B'],
    totalSeats: 900,
    pos: { en: 'North student dorms', zh: '北部学生宿舍' },
  },
  {
    id: 'zhichun',
    name: { en: 'Zhichun Garden', zh: '芝春园' },
    floors: ['1F', '2F'],
    zones: ['A', 'B'],
    totalSeats: 600,
    pos: { en: 'Near teaching area', zh: '教学区附近' },
  },
  {
    id: 'qingfen',
    name: { en: 'Qingfen Canteen', zh: '清芬食堂' },
    floors: ['1F', '2F'],
    zones: ['A', 'B'],
    totalSeats: 750,
    pos: { en: 'East campus', zh: '东区' },
  },
  {
    id: 'guanyuan',
    name: { en: 'Guanyuan Canteen', zh: '观园食堂' },
    floors: ['1F'],
    zones: ['A'],
    totalSeats: 350,
    pos: { en: 'International student area', zh: '留学生区' },
  },
];

// Peak-hour patterns (simulated) per canteen, used for beta "avoid the rush"
const peakHours = {
  zijin: { lunch: '11:30–12:30', dinner: '17:30–18:30' },
  taoli: { lunch: '11:45–12:45', dinner: '17:45–18:45' },
  zhichun: { lunch: '11:20–12:20', dinner: '17:20–18:20' },
  qingfen: { lunch: '11:30–12:30', dinner: '17:30–18:30' },
  guanyuan: { lunch: '12:00–13:00', dinner: '18:00–19:00' },
};

module.exports = { canteens, peakHours };
