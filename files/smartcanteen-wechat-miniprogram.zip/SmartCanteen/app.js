// app.js — SmartCanteen global logic
const i18n = require('./i18n/i18n');

App({
  globalData: {
    lang: 'en',           // 'en' | 'zh'
    dietaryPrefs: [],     // active dietary filters, e.g. ['vegetarian','noPork']
    allergens: [],        // allergy list, e.g. ['peanut']
    maxPrice: null,       // optional price cap
    focusSearch: false,   // transient flag: home search -> focus dishes search box
  },

  onLaunch() {
    // restore saved preferences
    const prefs = wx.getStorageSync('smartcanteen_prefs');
    if (prefs && typeof prefs === 'object') {
      this.globalData.dietaryPrefs = prefs.dietaryPrefs || [];
      this.globalData.allergens = prefs.allergens || [];
      this.globalData.maxPrice = prefs.maxPrice || null;
      if (prefs.lang) this.globalData.lang = prefs.lang;
    }
  },

  setLang(lang) {
    this.globalData.lang = lang;
    this._persist();
  },

  togglePref(kind, value) {
    const arr = this.globalData[kind];
    const i = arr.indexOf(value);
    if (i >= 0) arr.splice(i, 1);
    else arr.push(value);
    this._persist();
  },

  setMaxPrice(v) {
    this.globalData.maxPrice = v;
    this._persist();
  },

  _persist() {
    wx.setStorageSync('smartcanteen_prefs', {
      lang: this.globalData.lang,
      dietaryPrefs: this.globalData.dietaryPrefs,
      allergens: this.globalData.allergens,
      maxPrice: this.globalData.maxPrice,
    });
  },

  // convenience: translate a key for current language
  t(key) {
    return i18n.t(this.globalData.lang, key);
  },
});
