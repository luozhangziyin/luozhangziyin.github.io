# -*- coding: utf-8 -*-
"""Generate a standalone HTML design preview of SmartCanteen."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "preview.html")

CSS = """<style>
:root{--p:#663399;--pl:#7b4bb8;--bg:#f5f5f7;--card:#fff;--ink:#1c1c1e;--m:#8a8a8e;--g:#2e9e58;--a:#e6a23c;--r:#c0392b}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Segoe UI",sans-serif;background:#ececf0;color:var(--ink);padding:32px}
h1{font-size:22px;margin-bottom:4px}
.sub{color:var(--m);margin-bottom:28px;font-size:14px}
.stage{display:flex;flex-wrap:wrap;gap:28px;align-items:flex-start;justify-content:center}
.phone{width:320px;background:#000;border-radius:40px;padding:10px;box-shadow:0 20px 50px rgba(0,0,0,.25)}
.screen{width:300px;height:620px;background:var(--bg);border-radius:32px;overflow:hidden;display:flex;flex-direction:column}
.notch{height:26px}
.cap{text-align:center;font-size:12px;color:var(--m);margin:16px 0 6px;font-weight:600}
.scroll{flex:1;overflow-y:auto;padding:0 12px 16px}
.scroll::-webkit-scrollbar{display:none}
.hero{background:linear-gradient(160deg,var(--p),var(--pl));color:#fff;border-radius:0 0 22px 22px;padding:18px 16px 22px;margin:0 -12px 14px}
.hero.r{border-radius:22px;margin:8px -12px 14px}
.brand{font-size:21px;font-weight:800}
.bsub{font-size:12px;opacity:.9;margin-top:2px}
.langbtn{background:rgba(255,255,255,.2);padding:5px 12px;border-radius:99px;font-size:12px;font-weight:600;float:right;margin-top:-34px}
.search{background:#fff;border-radius:99px;padding:10px 14px;margin-top:14px;color:var(--m);font-size:12px;display:flex;gap:8px}
.quick{display:flex;gap:10px;margin-bottom:8px}
.qitem{flex:1;border-radius:16px;padding:16px;color:#fff;font-size:13px;font-weight:600}
.qitem.p{background:var(--p)}
.qitem.w{background:#fff;color:var(--p);box-shadow:0 2px 8px rgba(0,0,0,.06)}
.emoji{font-size:24px;display:block;margin-bottom:6px}
.sec{font-size:15px;font-weight:700;margin:18px 0 10px}
.hs{display:flex;gap:10px;overflow-x:auto;padding-bottom:4px}
.hs::-webkit-scrollbar{display:none}
.mini{width:140px;background:#fff;border-radius:14px;overflow:hidden;flex-shrink:0;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.mini img{width:140px;height:90px;object-fit:cover;display:block}
.mb{padding:8px 10px;font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mm{padding:0 10px 8px;font-size:10px;color:var(--m)}
.cc{background:#fff;border-radius:14px;padding:12px 14px;margin-bottom:10px;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.row{display:flex;justify-content:space-between;align-items:center}
.cn{font-size:14px;font-weight:700}
.cm{font-size:10px;color:var(--m);margin-top:2px}
.badge{font-size:11px;font-weight:700;padding:3px 10px;border-radius:99px}
.bl{background:#e7f7ec;color:#1e7d43}.bm{background:#fff3df;color:#a86b00}.bh{background:#fde8e8;color:#c0392b}.bv{background:#c0392b;color:#fff}
.bar{height:9px;background:#f0f0f2;border-radius:99px;margin-top:10px;overflow:hidden}
.fill{height:100%;border-radius:99px}
.curve{display:flex;align-items:flex-end;height:70px;gap:2px;margin-top:12px}
.curve i{flex:1;background:#d9c8ec;border-radius:2px 2px 0 0;min-height:3px}
.curve i.now{background:var(--p)}
.peakrow{margin-top:12px;display:flex;gap:6px;flex-wrap:wrap}
.ptag{font-size:10px;padding:3px 10px;border-radius:99px;background:#fff3df;color:#a86b00}
.tabbar{height:56px;background:#fff;border-top:1px solid #eee;display:flex;align-items:center;justify-content:space-around;font-size:10px;color:var(--m);flex-shrink:0}
.tab{display:flex;flex-direction:column;align-items:center;gap:2px}
.tab .ic{font-size:20px}
.tab.on{color:var(--p);font-weight:600}
.dh img{width:100%;height:180px;object-fit:cover;display:block}
.dtc{background:#fff;border-radius:16px;padding:14px;margin:-26px 0 0;position:relative;box-shadow:0 2px 10px rgba(0,0,0,.08)}
.dn{font-size:19px;font-weight:800}
.dz{font-size:12px;color:var(--m);margin-top:2px}
.price{font-size:20px;font-weight:800;color:var(--p);float:right;margin-top:-34px}
.chef{margin-top:12px;background:#fff7e6;border:2px dashed var(--a);border-radius:12px;padding:9px 12px;font-size:12px;color:#a86b00;font-weight:600}
.tags{margin-top:10px;display:flex;gap:6px;flex-wrap:wrap}
.tag{font-size:10px;padding:3px 10px;border-radius:99px;background:#efe7f7;color:var(--p)}
.tag.red{background:#fde8e8;color:#c0392b}
.card{background:#fff;border-radius:14px;padding:12px 14px;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.ingr{display:inline-block;background:#f5f5f7;padding:5px 12px;border-radius:99px;font-size:10px;margin:0 6px 6px 0}
.warn{font-size:12px;line-height:1.5}
.kcal{font-size:32px;font-weight:800;color:var(--p)}
.macro{display:flex;gap:14px;margin-top:10px}
.macro .col{flex:1}
.macro .val{font-size:16px;font-weight:700}
.macro .lab{font-size:9px;color:var(--m);margin:2px 0 6px}
.macro .bar{height:8px;background:#f0f0f2;border-radius:99px;overflow:hidden;margin:0}
.macro .bar div{height:100%}
</style>"""

TAB = """<div class="tabbar">
<div class="tab{0}"><span class="ic">🏠</span>Home</div>
<div class="tab{1}"><span class="ic">🥢</span>Dishes</div>
<div class="tab{2}"><span class="ic">📊</span>Crowd</div>
<div class="tab{3}"><span class="ic">👤</span>Me</div>
</div>"""

# 24h busyness curve heights (rpx-ish px)
curve = [3,3,3,3,4,6,18,42,36,25,36,60,70,52,28,25,38,63,70,56,35,21,14,7]
def curve_html(now=20):
    parts = []
    for h, v in enumerate(curve):
        cls = ' class="now"' if h == now else ''
        parts.append(f'<i{cls} style="height:{v}px"></i>')
    return '<div class="curve">' + ''.join(parts) + '</div>'

home = f"""
<div>
<div class="cap">HOME — crowd overview</div>
<div class="phone"><div class="screen"><div class="notch"></div><div class="scroll">
<div class="hero">
<div class="langbtn">中文</div>
<div class="brand">🍜 SmartCanteen</div>
<div class="bsub">Good meal, Tsinghua!</div>
<div class="search">🔍 Search dishes, ingredients…</div>
</div>
<div class="quick">
<div class="qitem p"><span class="emoji">🥢</span>Browse all dishes</div>
<div class="qitem w"><span class="emoji">🎯</span>My preferences</div>
</div>
<div class="sec">Browse all dishes</div>
<div class="hs">
<div class="mini"><img src="images/dishes/mapo_tofu.png"><div class="mb">Mapo Tofu</div><div class="mm">¥12 · 2F #14</div></div>
<div class="mini"><img src="images/dishes/kungpao.png"><div class="mb">Kung Pao Chicken</div><div class="mm">¥15 · 1F #08</div></div>
<div class="mini"><img src="images/dishes/beef_noodle.png"><div class="mb">Beef Noodle Soup</div><div class="mm">¥18 · 1F #03</div></div>
</div>
<div class="sec">Crowd right now</div>
<div class="cc"><div class="row"><div><div class="cn">Zijing Canteen</div><div class="cm">~210 people now · 970 seats free</div></div><div class="badge bl">19%</div></div><div class="bar"><div class="fill" style="width:19%;background:#2e9e58"></div></div></div>
<div class="cc"><div class="row"><div><div class="cn">Taoli Canteen</div><div class="cm">~160 people now · 720 seats free</div></div><div class="badge bl">20%</div></div><div class="bar"><div class="fill" style="width:20%;background:#2e9e58"></div></div></div>
<div class="cc"><div class="row"><div><div class="cn">Guanyuan Canteen</div><div class="cm">~85 people now · 260 seats free</div></div><div class="badge bl">27%</div></div><div class="bar"><div class="fill" style="width:27%;background:#2e9e58"></div></div></div>
</div>
{TAB.format(" on","","","")}
</div></div></div>
"""

dish = f"""
<div>
<div class="cap">DISH DETAIL — allergens &amp; nutrition</div>
<div class="phone"><div class="screen"><div class="notch"></div><div class="scroll">
<div class="dh"><img src="images/dishes/kungpao.png"></div>
<div class="dtc">
<div class="price">¥15</div>
<div class="dn">Kung Pao Chicken</div>
<div class="dz">宫保鸡丁</div>
<div class="chef">👨‍🍳 Show chef name</div>
<div class="tags"><span class="tag">Halal</span><span class="tag red">Spicy</span></div>
</div>
<div class="sec">Location</div>
<div class="card">📍 Zijing Canteen · 1F · #08</div>
<div class="sec">Ingredients</div>
<div class="card"><span class="ingr">Chicken</span><span class="ingr">Peanuts</span><span class="ingr">Dried chili</span><span class="ingr">Scallion</span><span class="ingr">Sugar</span></div>
<div class="sec">Allergens</div>
<div class="card"><div class="warn">⚠️ Contains: <b style="color:#c0392b">Peanut</b></div></div>
<div class="sec">Nutrition</div>
<div class="card"><span class="kcal">480</span> <span style="font-size:11px;color:#8a8a8e">kcal / serving</span>
<div class="macro">
<div class="col"><div class="val">30%</div><div class="lab">Protein</div><div class="bar"><div style="width:30%;background:#663399"></div></div></div>
<div class="col"><div class="val">26%</div><div class="lab">Fat</div><div class="bar"><div style="width:26%;background:#e6a23c"></div></div></div>
<div class="col"><div class="val">18%</div><div class="lab">Carbs</div><div class="bar"><div style="width:18%;background:#2e9e58"></div></div></div>
</div></div>
</div>
{TAB.format(""," on","","")}
</div></div></div>
"""

crowd = f"""
<div>
<div class="cap">CROWD — 24h peak curve</div>
<div class="phone"><div class="screen"><div class="notch"></div><div class="scroll">
<div class="hero r"><div class="brand" style="font-size:17px">📊 Crowd right now</div><div class="bsub">Find food you can eat, fast.</div></div>
<div class="cc"><div class="row"><div><div class="cn">Zijing Canteen</div><div class="cm">~210 people · 970 seats free</div></div><div class="badge bl">19%</div></div>{curve_html()}
<div class="peakrow"><span class="ptag">🍚 Busiest 11:30–12:30</span><span class="ptag">🍲 17:30–18:30</span></div></div>
<div class="cc"><div class="row"><div><div class="cn">Guanyuan Canteen</div><div class="cm">~85 people · 260 seats free</div></div><div class="badge bm">27%</div></div>{curve_html(19)}
<div class="peakrow"><span class="ptag">🍚 Busiest 12:00–13:00</span><span class="ptag">🍲 18:00–19:00</span></div></div>
</div>
{TAB.format("",""," on","")}
</div></div></div>
"""

html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SmartCanteen — Design Preview</title>{CSS}</head>
<body><h1>🍜 SmartCanteen — Design Preview</h1>
<p class="sub">Three key screens. Open the project in WeChat DevTools for the interactive version.</p>
<div class="stage">{home}{dish}{crowd}</div></body></html>"""

with open(OUT, "w", encoding="utf-8") as f:
    f.write(html)
print("wrote", OUT, len(html), "bytes")
