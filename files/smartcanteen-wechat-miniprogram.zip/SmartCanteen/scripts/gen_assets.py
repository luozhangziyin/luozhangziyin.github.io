# -*- coding: utf-8 -*-
"""Generate tab-bar icons and dish placeholder images for SmartCanteen."""
from PIL import Image, ImageDraw, ImageFont
import os, math

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TAB = os.path.join(ROOT, "images", "tab")
DISH = os.path.join(ROOT, "images", "dishes")
os.makedirs(TAB, exist_ok=True)
os.makedirs(DISH, exist_ok=True)

# ---- palette (Tsinghua purple + accent) ----
PURPLE = (102, 51, 153)      # #663399
PURPLE_D = (74, 35, 120)     # deeper
GRAY = (154, 160, 170)
WHITE = (255, 255, 255)

def new(size=(96, 96), bg=(0, 0, 0, 0)):
    return Image.new("RGBA", size, bg)

def draw_icon(kind, color, size=96):
    img = new((size, size))
    d = ImageDraw.Draw(img)
    s = size
    sw = max(2, s // 12)  # stroke width
    if kind == "home":
        # house outline
        roof = [(s*0.5, s*0.18), (s*0.14, s*0.48), (s*0.86, s*0.48)]
        d.polygon(roof, outline=color, width=sw)
        d.rectangle([s*0.22, s*0.46, s*0.78, s*0.82], outline=color, width=sw)
        d.rectangle([s*0.44, s*0.60, s*0.56, s*0.82], fill=color)
    elif kind == "bowl":  # dishes / food
        # bowl
        d.arc([s*0.12, s*0.42, s*0.88, s*0.95], 0, 180, fill=color, width=sw)
        d.line([s*0.12, s*0.68, s*0.88, s*0.68], fill=color, width=sw)
        # chopsticks
        d.line([s*0.30, s*0.30, s*0.48, s*0.58], fill=color, width=sw)
        d.line([s*0.62, s*0.30, s*0.44, s*0.58], fill=color, width=sw)
    elif kind == "report":  # crowd / chart
        # bar chart
        d.rectangle([s*0.18, s*0.62, s*0.36, s*0.86], fill=color)
        d.rectangle([s*0.42, s*0.42, s*0.60, s*0.86], fill=color)
        d.rectangle([s*0.66, s*0.24, s*0.84, s*0.86], fill=color)
    elif kind == "user":
        # person
        d.ellipse([s*0.34, s*0.16, s*0.66, s*0.48], outline=color, width=sw)
        d.arc([s*0.20, s*0.46, s*0.80, s*1.06], 0, 180, fill=color, width=sw)
    return img

for kind in ["home", "bowl", "report", "user"]:
    normal = draw_icon(kind, GRAY)
    active = draw_icon(kind, PURPLE)
    normal.save(os.path.join(TAB, f"{kind}.png"))
    active.save(os.path.join(TAB, f"{kind}-active.png"))

# ---- dish placeholder images ----
DISH_NAMES = {
    "mapo_tofu": ("Mapo Tofu", (200, 70, 50)),
    "kungpao": ("Kung Pao Chicken", (210, 120, 40)),
    "beef_noodle": ("Beef Noodle Soup", (150, 90, 40)),
    "dumplings": ("Pork Dumplings", (220, 200, 160)),
    "veggie": ("Stir-fried Greens", (60, 140, 70)),
    "rice": ("Yangzhou Fried Rice", (220, 190, 90)),
    "tomato_egg": ("Tomato & Egg", (210, 60, 50)),
    "sweet_sour": ("Sweet & Sour Pork", (200, 90, 60)),
    "hotpot": ("Mini Hotpot", (180, 40, 40)),
    "noodles": ("Zha Jiang Noodles", (170, 120, 60)),
    "congee": ("Pork Congee", (230, 225, 200)),
    "salad": ("Garden Salad", (90, 160, 90)),
}

def dish_card(key, label, base_color, size=600):
    img = new((size, size), WHITE)
    d = ImageDraw.Draw(img)
    r, g, b = base_color
    # gradient-ish bands
    for i in range(size):
        t = i / size
        col = (int(r + (255-r)*t*0.35), int(g + (255-g)*t*0.35), int(b + (255-b)*t*0.35))
        d.line([(0, i), (size, i)], fill=col)
    # plate circle
    plate = (size//2, int(size*0.52))
    pr = int(size*0.30)
    d.ellipse([plate[0]-pr, plate[1]-pr, plate[0]+pr, plate[1]+pr], fill=WHITE, outline=(230,230,230), width=6)
    # inner food blob
    br = int(pr*0.62)
    d.ellipse([plate[0]-br, plate[1]-br, plate[0]+br, plate[1]+br], fill=base_color)
    # highlight dots (ingredients)
    for k in range(9):
        ang = (k/9)*2*math.pi + 0.3
        x = plate[0] + int(math.cos(ang)*br*0.55)
        y = plate[1] + int(math.sin(ang)*br*0.55)
        dot = (min(255, r+60), min(255, g+60), min(255, b+40))
        d.ellipse([x-16, y-16, x+16, y+16], fill=dot)
    return img

for key, (label, col) in DISH_NAMES.items():
    dish_card(key, label, col).save(os.path.join(DISH, f"{key}.png"))

# a couple of extra generic fallbacks
dish_card("generic1", "dish", (160, 160, 170)).save(os.path.join(DISH, "generic1.png"))
dish_card("generic2", "dish", (150, 110, 170)).save(os.path.join(DISH, "generic2.png"))

print("generated", len(os.listdir(TAB)), "tab icons and", len(os.listdir(DISH)), "dish images")
