// pages/canteen/canteen.js
const app = getApp();
const i18n = require('../../i18n/i18n');
const { getCanteen } = require('../../utils/util');
const { getCrowdSnapshot } = require('../../data/crowd');
const { peakHours } = require('../../data/canteens');
const { filterDishes } = require('../../utils/util');

Page({
  data: {
    lang: 'en',
    t: {},
    canteen: null,
    snap: null,
    peak: null,
    dishes: [],
  },

  onLoad(options) {
    const c = getCanteen(options.id);
    if (!c) {
      wx.showToast({ title: 'Not found', icon: 'none' });
      setTimeout(() => wx.navigateBack(), 800);
      return;
    }
    this.setData({ canteen: c });
    this.refresh();
  },

  onShow() {
    if (this.data.canteen) this.refresh();
  },

  refresh() {
    const lang = app.globalData.lang;
    const snap = getCrowdSnapshot().find((s) => s.id === this.data.canteen.id);
    const dishes = filterDishes({ canteenId: this.data.canteen.id });
    this.setData({
      lang,
      t: i18n[lang],
      snap,
      peak: peakHours[this.data.canteen.id],
      dishes,
    });
  },

  goDish(e) {
    wx.navigateTo({ url: `/pages/dish/dish?id=${e.currentTarget.dataset.id}` });
  },
});
