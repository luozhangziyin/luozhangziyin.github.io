// pages/profile/profile.js
const app = getApp();
const i18n = require('../../i18n/i18n');
const { getFavorites, getDish, dayNutrition, lastNDays } = require('../../utils/util');

const DIETARY_OPTIONS = [
  { key: 'vegetarian', icon: '🥬' },
  { key: 'vegan', icon: '🌱' },
  { key: 'halal', icon: '🕌' },
  { key: 'noPork', icon: '🐷' },
  { key: 'noBeef', icon: '🐮' },
];

const ALLERGEN_OPTIONS = ['Peanut', 'Soy', 'Wheat', 'Egg', 'Sesame', 'Shellfish'];

Page({
  data: {
    lang: 'en',
    t: {},
    dietaryOptions: DIETARY_OPTIONS,
    allergenOptions: ALLERGEN_OPTIONS,
    dietaryPrefs: [],
    allergens: [],
    maxPrice: null,
    favorites: [],
    // nutrition record
    today: null,
    pastDays: [],
    hasMeals: false,
    // login
    user: null,
  },

  onShow() {
    this.refresh();
  },

  refresh() {
    const lang = app.globalData.lang;
    const favs = getFavorites().map((id) => {
      const d = getDish(id);
      return d ? { id: d.id, name: d.name[lang], img: d.img, price: d.price } : null;
    }).filter(Boolean);

    // Precompute selected flags so the WXML never has to call .indexOf()
    const dietaryPrefs = app.globalData.dietaryPrefs || [];
    const allergens = app.globalData.allergens || [];
    const dietaryOptions = DIETARY_OPTIONS.map((o) => ({
      ...o,
      on: dietaryPrefs.indexOf(o.key) >= 0,
    }));
    const allergenOptions = ALLERGEN_OPTIONS.map((a) => ({
      name: a,
      on: allergens.indexOf(a) >= 0,
    }));

    // Nutrition record: today's aggregate + a 7-day history
    const days = lastNDays(7);
    const today = dayNutrition(days[days.length - 1].key);
    const pastDays = days.map((d) => {
      const n = dayNutrition(d.key);
      return { key: d.key, label: d.label, kcal: n ? n.kcal : 0, count: n ? n.count : 0 };
    });
    const maxKcal = Math.max(1, ...pastDays.map((d) => d.kcal));

    // Login state (stored locally; no cloud backend yet)
    const user = wx.getStorageSync('smartcanteen_user') || null;

    this.setData({
      lang,
      t: i18n[lang],
      dietaryPrefs,
      allergens,
      dietaryOptions,
      allergenOptions,
      maxPrice: app.globalData.maxPrice,
      favorites: favs,
      today,
      pastDays,
      maxKcal,
      hasMeals: !!today,
      user,
    });
  },

  toggleDiet(e) {
    const key = e.currentTarget.dataset.key;
    app.togglePref('dietaryPrefs', key);
    this.refresh();
  },

  toggleAllergen(e) {
    const key = e.currentTarget.dataset.key;
    app.togglePref('allergens', key);
    this.refresh();
  },

  onPriceInput(e) {
    const v = e.detail.value;
    app.setMaxPrice(v === '' ? null : Number(v));
  },

  clearAll() {
    app.globalData.dietaryPrefs = [];
    app.globalData.allergens = [];
    app.globalData.maxPrice = null;
    app._persist();
    this.refresh();
  },

  toggleLang() {
    const next = app.globalData.lang === 'en' ? 'zh' : 'en';
    app.setLang(next);
    this.refresh();
  },

  goDish(e) {
    wx.navigateTo({ url: `/pages/dish/dish?id=${e.currentTarget.dataset.id}` });
  },

  // ---- login (WeChat profile; note: cloud sync still needs a backend) ----
  login() {
    if (wx.getUserProfile) {
      wx.getUserProfile({
        desc: '用于展示头像昵称',
        success: (res) => {
          const info = res.userInfo || {};
          const user = { nickName: info.nickName || 'User', avatarUrl: info.avatarUrl || '' };
          wx.setStorageSync('smartcanteen_user', user);
          this.refresh();
        },
        fail: () => {
          wx.showToast({ title: 'Cancelled', icon: 'none' });
        },
      });
    } else {
      wx.showToast({ title: 'Not supported in this environment', icon: 'none' });
    }
  },

  logout() {
    wx.removeStorageSync('smartcanteen_user');
    this.refresh();
  },
});
