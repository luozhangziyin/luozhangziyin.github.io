// pages/report/report.js
const app = getApp();
const i18n = require('../../i18n/i18n');
const { getDish } = require('../../utils/util');

const TYPES = [
  { key: 'sold_out', icon: '🈳' },
  { key: 'wrong_price', icon: '💸' },
  { key: 'wrong_location', icon: '📍' },
  { key: 'stall_closed', icon: '🚫' },
];

Page({
  data: {
    lang: 'en',
    t: {},
    types: TYPES,
    type: '',
    dish: null,
    dishName: '',
    submitted: false,
  },

  onLoad(options) {
    if (options && options.id) {
      const d = getDish(options.id);
      if (d) {
        this.setData({
          dish: d,
          dishName: app.globalData.lang === 'zh' ? d.name.zh : d.name.en,
        });
      }
    }
    this.refresh();
  },

  onShow() {
    this.refresh();
  },

  refresh() {
    const lang = app.globalData.lang;
    this.setData({ lang, t: i18n[lang] });
  },

  pickType(e) {
    this.setData({ type: e.currentTarget.dataset.key });
  },

  submit() {
    if (!this.data.type) {
      wx.showToast({ title: this.data.t.pick_one || 'Choose a type', icon: 'none' });
      return;
    }
    // In production, POST to backend; here we persist locally.
    const reports = wx.getStorageSync('smartcanteen_reports') || [];
    reports.push({
      dishId: this.data.dish ? this.data.dish.id : null,
      type: this.data.type,
      time: Date.now(),
      status: 'pending',
    });
    wx.setStorageSync('smartcanteen_reports', reports);
    this.setData({ submitted: true });
  },

  again() {
    this.setData({ type: '', submitted: false });
  },
});
