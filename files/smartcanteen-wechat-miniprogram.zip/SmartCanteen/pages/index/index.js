// pages/index/index.js
const app = getApp();
const { canteens } = require('../../data/canteens');
const { getCrowdSnapshot } = require('../../data/crowd');
const { filterDishes } = require('../../utils/util');
const i18n = require('../../i18n/i18n');

Page({
  data: {
    lang: 'en',
    t: {},
    canteens: [],
    featured: [],
  },

  onLoad() {
    this.refresh();
  },

  onShow() {
    this.refresh();
  },

  refresh() {
    const lang = app.globalData.lang;
    const snap = getCrowdSnapshot();
    this.setData({
      lang,
      t: i18n[lang],
      canteens: snap,
      featured: filterDishes({}).slice(0, 6),
    });
  },

  toggleLang() {
    const next = app.globalData.lang === 'en' ? 'zh' : 'en';
    app.setLang(next);
    this.refresh();
  },

  onSearch() {
    // dishes is a tab-bar page, so we must switchTab (not navigateTo)
    app.globalData.focusSearch = true;
    wx.switchTab({ url: '/pages/dishes/dishes' });
  },

  goDishes() {
    wx.switchTab({ url: '/pages/dishes/dishes' });
  },

  goProfile() {
    wx.switchTab({ url: '/pages/profile/profile' });
  },

  goCanteen(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/canteen/canteen?id=${id}` });
  },

  goDish(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/dish/dish?id=${id}` });
  },
});
