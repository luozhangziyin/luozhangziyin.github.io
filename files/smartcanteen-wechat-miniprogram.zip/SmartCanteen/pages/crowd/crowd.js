// pages/crowd/crowd.js
const app = getApp();
const i18n = require('../../i18n/i18n');
const { getCrowdSnapshot, levelOf, timeFactor } = require('../../data/crowd');
const { peakHours } = require('../../data/canteens');

// Simple per-canteen hourly curve for the "peak hours" mini chart (24h).
// Values are relative busyness 0..1, synthetic for demo.
const HOURLY = [0.02, 0.01, 0.01, 0.01, 0.02, 0.05, 0.25, 0.6, 0.5, 0.35, 0.5, 0.85, 1.0, 0.75, 0.4, 0.35, 0.55, 0.9, 1.0, 0.8, 0.5, 0.3, 0.2, 0.1];

Page({
  data: {
    lang: 'en',
    t: {},
    canteens: [],
    hourly: HOURLY,
    maxHourly: 1,
    nowHour: new Date().getHours(),
  },

  onLoad() {
    this.refresh();
  },

  onShow() {
    this.refresh();
  },

  refresh() {
    const lang = app.globalData.lang;
    const snap = getCrowdSnapshot();
    const list = snap.map((s) => ({
      ...s,
      peak: peakHours[s.id],
      name: s.name,
      hours: HOURLY.map((v, h) => ({ h, v })),
    }));
    this.setData({
      lang,
      t: i18n[lang],
      canteens: list,
      nowHour: new Date().getHours(),
    });
  },

  goCanteen(e) {
    wx.navigateTo({ url: `/pages/canteen/canteen?id=${e.currentTarget.dataset.id}` });
  },
});
