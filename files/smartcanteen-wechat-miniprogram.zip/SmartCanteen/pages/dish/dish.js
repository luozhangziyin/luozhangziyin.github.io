// pages/dish/dish.js
const app = getApp();
const i18n = require('../../i18n/i18n');
const { getDish, getCanteen, dietTags, isFavorite, toggleFavorite, logMeal } = require('../../utils/util');

Page({
  data: {
    lang: 'en',
    t: {},
    dish: null,
    canteen: null,
    tags: [],
    fav: false,
  },

  onLoad(options) {
    const dish = getDish(options.id);
    if (!dish) {
      wx.showToast({ title: 'Not found', icon: 'none' });
      setTimeout(() => wx.navigateBack(), 800);
      return;
    }
    this.setData({ dish });
    this.refresh();
  },

  onShow() {
    if (this.data.dish) this.refresh();
  },

  refresh() {
    const lang = app.globalData.lang;
    const d = this.data.dish;
    const canteen = getCanteen(d.canteenId);
    this.setData({
      lang,
      t: i18n[lang],
      canteen,
      canteenName: canteen ? canteen.name[lang] : '',
      allergensJoined: (d.allergens || []).join(', '),
      tags: dietTags(d, lang),
      fav: isFavorite(d.id),
    });
  },

  toggleFav() {
    const now = toggleFavorite(this.data.dish.id);
    this.setData({ fav: now });
    wx.showToast({
      title: now ? '★ Saved' : 'Removed',
      icon: 'none',
    });
  },

  report() {
    wx.navigateTo({ url: `/pages/report/report?id=${this.data.dish.id}` });
  },

  logMeal() {
    logMeal(this.data.dish.id);
    wx.showToast({ title: this.data.t.logged, icon: 'success' });
  },

  // "show chef" — reveal Chinese name prominently so staff understand
  showChef() {
    wx.showModal({
      title: this.data.dish.name.zh,
      content: 'Show this Chinese name to the canteen chef so they know which dish to prepare.',
      confirmText: 'OK',
      showCancel: false,
    });
  },
});
