// pages/dishes/dishes.js
const app = getApp();
const i18n = require('../../i18n/i18n');
const { filterDishes, dietTags, getCanteen } = require('../../utils/util');
const { canteens } = require('../../data/canteens');

Page({
  data: {
    lang: 'en',
    t: {},
    query: '',
    canteenFilter: '',
    dietaryFilter: '',
    dishes: [],
    canteens: [],
    focus: false,
  },

  onLoad(options) {
    if (options && options.focus) this.setData({ focus: true });
    this.setData({ canteens });
    this.apply();
  },

  onShow() {
    // home search taps "search" -> switchTab here; honour the focus flag once
    if (app.globalData.focusSearch) {
      app.globalData.focusSearch = false;
      this.setData({ focus: true });
    }
    this.apply();
  },

  apply() {
    const lang = app.globalData.lang;
    const prefs = app.globalData;
    const opts = {
      query: this.data.query,
      canteenId: this.data.canteenFilter || null,
      dietaryPrefs: prefs.dietaryPrefs,
      allergens: prefs.allergens,
      maxPrice: prefs.maxPrice,
    };
    // dietary filter chip (single-select) overrides globally saved prefs for clarity
    if (this.data.dietaryFilter) {
      opts.dietaryPrefs = [this.data.dietaryFilter];
    }
    let list = filterDishes(opts).map((d) => ({
      ...d,
      tags: dietTags(d, lang),
      canteenName: getCanteen(d.canteenId)?.name[lang] || '',
    }));
    this.setData({ dishes: list, lang, t: i18n[lang] });
  },

  onInput(e) {
    this.setData({ query: e.detail.value });
    this.apply();
  },

  onCanteenPick(e) {
    const v = e.currentTarget.dataset.v || '';
    // tapping the active filter again un-selects it
    this.setData({ canteenFilter: this.data.canteenFilter === v ? '' : v });
    this.apply();
  },

  onDietPick(e) {
    const v = e.currentTarget.dataset.v || '';
    this.setData({ dietaryFilter: this.data.dietaryFilter === v ? '' : v });
    this.apply();
  },

  goDish(e) {
    wx.navigateTo({ url: `/pages/dish/dish?id=${e.currentTarget.dataset.id}` });
  },

  goProfile() {
    wx.switchTab({ url: '/pages/profile/profile' });
  },
});
