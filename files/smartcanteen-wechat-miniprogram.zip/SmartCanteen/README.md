# SmartCanteen 🍜

A WeChat Mini Program that catalogues every dish in Tsinghua's canteens — bilingual
(English + Chinese), with ingredients, allergens, nutrition, dietary tags, price and
location — plus a beta **real-time crowd & peak-hour** monitor so freshmen (especially
international students) can avoid the rush.

## Features

| Feature | Description |
| --- | --- |
| 🌍 Bilingual | Every dish has an English + Chinese name. Tap **"Show chef name"** to reveal the Chinese name for canteen staff. |
| 🥢 Dish catalogue | 12 sample dishes across 5 canteens, each with image, price, ingredients, allergens, nutrition (kcal + protein/fat/carbs %), dietary tags, exact floor & stall. |
| ⚠️ Allergen safety | Distinguishes **"verified free of"** vs **"info unavailable"**. Allergy filters also hide unknown-info dishes for safety. |
| 🎯 Personalised discovery | Dietary prefs (vegetarian / vegan / halal / no pork / no beef), allergen filters, price cap, text search. |
| 📊 Live crowd (beta) | Per-canteen occupancy %, people count, free seats, zone-level density, and a 24h peak-hour curve. |
| 🕐 Peak hours | Lunch/dinner peak windows per canteen so students can time their visit. |
| 📣 Crowdsourcing | Report sold-out dishes, wrong prices/locations, or closed stalls (recorded with time + status). |
| ⭐ Favourites | Save dishes for quick access. |
| 📝 Nutrition record | "Log to my meal" on any dish; see today's kcal/protein/fat/carbs and a 7-day history bar chart on the Me page. |
| 👤 WeChat login | Sign in on the Me page to show your WeChat avatar + nickname. |

## Project structure

```
SmartCanteen/
├── app.json / app.js / app.wxss     global config, logic, styles
├── project.config.json              WeChat DevTools project config
├── sitemap.json
├── i18n/i18n.js                     English + Chinese strings
├── data/
│   ├── canteens.js                  canteen catalogue + peak hours
│   ├── dishes.js                    the food catalogue (12 sample dishes)
│   └── crowd.js                     simulated real-time crowd (beta)
├── utils/util.js                    filtering, favourites, helpers
├── pages/
│   ├── index/        Home (search, featured, crowd overview)
│   ├── dishes/       Browse + filter + search
│   ├── dish/         Dish detail (ingredients, allergens, nutrition, chef name)
│   ├── canteen/      Canteen detail (zones, peak hours, dishes)
│   ├── crowd/        Live crowd tab (24h curve per canteen)
│   ├── report/       Crowdsourcing form
│   └── profile/      Dietary prefs, allergens, language, favourites
└── images/           app icon, tab icons, dish photos
```

## Run it

1. Download **WeChat DevTools** (微信开发者工具) from
   https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html
2. Open WeChat DevTools → **Import project** → select the `SmartCanteen` folder.
3. AppID: the project uses `touristappid` (test mode) — you can open it without an AppID,
   or replace `"appid"` in `project.config.json` with your own.
4. Click **Compile**. The app runs immediately with mock data (no backend needed).

> Tip: `images/` is not shown in this summary because images are rendered inside the
> Mini Program itself.

## Swapping mock data for the real thing

The whole prototype is self-contained. When you're ready to go live:

- **Food data** → replace `data/dishes.js` with API calls to your database (see the
  PDF: PostgreSQL / MySQL / Firebase were proposed).
- **Crowd data** → replace `data/crowd.js` `getCrowdSnapshot()` with a request to your
  occupancy backend (fed by the QR-code / camera → YOLO → occupancy pipeline described
  in the project PDF).
- **Reports** → `pages/report/report.js` currently persists locally; point it at your API.
- **Nutrition record** → `utils/util.js` (`logMeal` / `dayNutrition`) stores meals
  locally keyed by day. To persist across devices, point it at a backend.
- **Login** → `pages/profile/profile.js` uses `wx.getUserProfile()` for the avatar +
  nickname. Data (prefs, meals, favourites) is stored **on-device** via `wx.setStorageSync`;
  true cross-device sync requires a backend + your own account system.

## Design notes

- Purple (`#663399`) — a nod to Tsinghua's colour.
- Chinese stock-market convention not needed here, but nutrition bars use a
  colour-blind-friendly palette.
